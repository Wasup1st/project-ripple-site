__turbopack_load_page_chunks__("/get-involved", [
  "static/chunks/[root of the server]__727d944b._.js",
  "static/chunks/node_modules_next_540031cf._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_64382200._.js",
  "static/chunks/src_pages_get-involved_5771e187._.js",
  "static/chunks/src_pages_get-involved_2939546c._.js"
])
