(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages__app_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages__app_5771e187._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_eb81a647._.js",
    "static/chunks/node_modules_react_1cad9b0b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
    "static/chunks/node_modules_react-dom_f14d0471._.js",
    "static/chunks/node_modules_69e050bc._.js",
    "static/chunks/[root of the server]__659f318b._.js",
    "static/chunks/src_styles_globals_4738091e.css"
  ],
  "source": "entry"
});
