__turbopack_load_page_chunks__("/contact", [
  "static/chunks/[root of the server]__2e1a43cb._.js",
  "static/chunks/node_modules_next_540031cf._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_e8be9964._.js",
  "static/chunks/src_pages_contact_5771e187._.js",
  "static/chunks/src_pages_contact_f57a1cf0._.js"
])
